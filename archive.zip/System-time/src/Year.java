import java.util.Scanner;
public class Year {

    public static void main(String[] args) {
        calculateLeapYear();
    }
    public static void calculateLeapYear() {
        Scanner scanner = new Scanner(System.in);
        int year;

        System.out.print("Enter the year: ");
        year = scanner.nextInt();

        if(year % 4 == 0){
            if(year % 100 == 0){
                if(year % 400 == 0){
                    System.out.printf("%d is a leap year", year);
                } else {
                    System.out.printf("%d is NOT a leap year", year);
                }
            } else {
                System.out.printf("%d is a leap year", year);
            }
        } else {
            System.out.printf("%d is NOT a leap year", year);
        }
    }
}

import java.util.Date;
public class SystemTime {
    public static void main(String[] args) {
            Date now = new Date();
            System.out.println("Now is: " + now);
    }
}


public class Main {
    public static void main(String[] args){
        int i = 10;
        float f = 20.5f;
        double d = 20.5;
        boolean b = true;
        char c = 'a';
        String s = "Hà Nội";
        System.out.print("i = " + i);
        System.out.print("f = " + f);
        System.out.print("d = " + d);
        System.out.print("b = " + b);
        System.out.print("c = " +c);
        System.out.print("s = " + s);
    }
}
